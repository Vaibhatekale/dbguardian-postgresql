from fastapi import FastAPI
from app.api import routes_health, routes_incidents, routes_queries, routes_rca, routes_recommendations

app = FastAPI(title="DBGuardian API")

app.include_router(routes_health.router)
app.include_router(routes_incidents.router)
app.include_router(routes_queries.router)
app.include_router(routes_rca.router)
app.include_router(routes_recommendations.router)