from fastapi import APIRouter
import psycopg2

router = APIRouter()

@router.get("/health")
def get_health():
    try:
        conn = psycopg2.connect(
            dbname="dbguardian",
            user="postgres",
            password="839045",
            host="localhost",
            port="5432"
        )
        cur = conn.cursor()

        cur.execute("SELECT COUNT(*) FROM db_metrics_raw;")
        metrics_count = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM incidents WHERE status = 'open';")
        open_incidents = cur.fetchone()[0]

        cur.close()
        conn.close()

        return {
            "status": "ok",
            "metrics_records": metrics_count,
            "open_incidents": open_incidents
        }

    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }