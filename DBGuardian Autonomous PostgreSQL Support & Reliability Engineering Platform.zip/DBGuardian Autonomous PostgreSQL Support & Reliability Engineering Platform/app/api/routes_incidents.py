from fastapi import APIRouter
import psycopg2

router = APIRouter()

@router.get("/incidents")
def get_incidents():
    conn = psycopg2.connect(
        dbname="dbguardian",
        user="postgres",
        password="839045",
        host="localhost",
        port="5432"
    )
    cur = conn.cursor()

    cur.execute("""
        SELECT id, title, severity, status, created_at
        FROM incidents
        ORDER BY created_at DESC;
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    incidents = []
    for row in rows:
        incidents.append({
            "id": row[0],
            "title": row[1],
            "severity": row[2],
            "status": row[3],
            "created_at": str(row[4])
        })

    return incidents