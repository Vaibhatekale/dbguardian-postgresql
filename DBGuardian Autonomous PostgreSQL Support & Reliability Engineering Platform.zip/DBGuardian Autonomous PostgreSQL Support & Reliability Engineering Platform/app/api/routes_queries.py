from fastapi import APIRouter
import psycopg2

router = APIRouter()

@router.get("/queries/top-slow")
def get_top_slow_queries():
    conn = psycopg2.connect(
        dbname="dbguardian",
        user="postgres",
        password="839045",
        host="localhost",
        port="5432"
    )
    cur = conn.cursor()

    cur.execute("""
        SELECT query_text, mean_exec_ms, calls
        FROM query_stats_raw
        ORDER BY mean_exec_ms DESC
        LIMIT 10;
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "query": row[0],
            "mean_exec_ms": row[1],
            "calls": row[2]
        })

    return result


@router.get("/queries/analyze/{query_id}")
def analyze_query(query_id: int):
    conn = psycopg2.connect(
        dbname="dbguardian",
        user="postgres",
        password="839045",
        host="localhost",
        port="5432"
    )
    cur = conn.cursor()

    cur.execute("""
        SELECT details
        FROM incident_evidence
        WHERE evidence_type = 'query_analysis'
        AND incident_id = 1
        ORDER BY created_at DESC
        LIMIT 1;
    """)

    row = cur.fetchone()

    cur.close()
    conn.close()

    return {
        "query_id": query_id,
        "analysis": row[0] if row else "No analysis found"
    }