from fastapi import APIRouter
import psycopg2

router = APIRouter()

@router.get("/rca/{incident_id}")
def get_rca(incident_id: int):
    conn = psycopg2.connect(
        dbname="dbguardian",
        user="postgres",
        password="839045",
        host="localhost",
        port="5432"
    )
    cur = conn.cursor()

    cur.execute("""
        SELECT incident_id, root_cause, recommendation, created_at
        FROM rca_reports
        WHERE incident_id = %s
        ORDER BY created_at DESC
        LIMIT 1;
    """, (incident_id,))

    row = cur.fetchone()

    cur.close()
    conn.close()

    if not row:
        return {"message": "No RCA found"}

    return {
        "incident_id": row[0],
        "root_cause": row[1],
        "recommendation": row[2],
        "created_at": str(row[3])
    }