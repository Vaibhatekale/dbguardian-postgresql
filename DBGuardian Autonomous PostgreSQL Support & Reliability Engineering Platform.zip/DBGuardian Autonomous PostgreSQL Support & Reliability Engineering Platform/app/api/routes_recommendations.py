from fastapi import APIRouter
import psycopg2

router = APIRouter()

@router.get("/recommendations")
def get_recommendations():
    conn = psycopg2.connect(
        dbname="dbguardian",
        user="postgres",
        password="839045",
        host="localhost",
        port="5432"
    )
    cur = conn.cursor()

    cur.execute("""
        SELECT suggestion, severity, created_at
        FROM recommendations
        ORDER BY created_at DESC
        LIMIT 20;
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "suggestion": row[0],
            "severity": row[1],
            "created_at": str(row[2])
        })

    return result