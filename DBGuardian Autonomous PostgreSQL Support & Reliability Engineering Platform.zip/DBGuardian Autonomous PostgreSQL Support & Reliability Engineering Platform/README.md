# DBGuardian — PostgreSQL Support & Reliability Platform

## Overview

DBGuardian is a PostgreSQL monitoring and reliability platform that detects slow queries, analyzes execution plans, identifies incidents, performs root cause analysis (RCA), and provides optimization recommendations.

## Features

* Slow query detection using pg_stat_statements
* Lock and activity monitoring using pg_stat_activity and pg_locks
* Incident detection system
* Query analysis using EXPLAIN ANALYZE
* Root Cause Analysis (RCA) engine
* Recommendation engine
* FastAPI-based API dashboard

## Tech Stack

* PostgreSQL
* Python
* FastAPI
* SQL / PLpgSQL

## Project Structure

* app/ → FastAPI APIs
* scripts/ → data generation & collectors
* data/ → CSV data
* database/ → SQL backup

## Setup

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:
http://127.0.0.1:8000/docs

## API Endpoints

* /health
* /incidents
* /queries/top-slow
* /queries/analyze/{query_id}
* /rca/{incident_id}
* /recommendations

## Use Cases

* Detect slow queries
* Analyze database performance
* Identify bottlenecks
* Generate RCA reports
* Suggest optimizations

## Note

This project simulates real-world database reliability engineering workflows using PostgreSQL internal statistics.
